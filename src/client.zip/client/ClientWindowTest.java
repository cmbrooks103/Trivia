package client;  

public class ClientWindowTest {
    public static void main(String[] args) {
        ClientWindow window = new ClientWindow();
    }
}